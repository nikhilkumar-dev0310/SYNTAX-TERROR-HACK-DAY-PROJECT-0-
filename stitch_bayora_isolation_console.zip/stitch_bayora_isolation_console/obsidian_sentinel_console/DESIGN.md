---
name: Obsidian Sentinel Console
colors:
  surface: '#101419'
  surface-dim: '#101419'
  surface-bright: '#36393f'
  surface-container-lowest: '#0a0e13'
  surface-container-low: '#181c21'
  surface-container: '#1c2025'
  surface-container-high: '#262a30'
  surface-container-highest: '#31353b'
  on-surface: '#e0e2ea'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e0e2ea'
  inverse-on-surface: '#2d3136'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#ffb3ae'
  on-secondary: '#68000c'
  secondary-container: '#a9011b'
  on-secondary-container: '#ffb3ae'
  tertiary: '#cebdff'
  on-tertiary: '#381385'
  tertiary-container: '#9b7fed'
  on-tertiary-container: '#31057e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#ffdad7'
  secondary-fixed-dim: '#ffb3ae'
  on-secondary-fixed: '#410005'
  on-secondary-fixed-variant: '#930016'
  tertiary-fixed: '#e8ddff'
  tertiary-fixed-dim: '#cebdff'
  on-tertiary-fixed: '#21005e'
  on-tertiary-fixed-variant: '#4f319c'
  background: '#101419'
  on-background: '#e0e2ea'
  surface-variant: '#31353b'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  mono-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
  mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-lg: 1rem
  margin: 1rem
  margin-mobile: 0.75rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system delivers an austere, mission-critical operations interface tailored for tier-3 security analysts, red/blue adversarial telemetry teams, and containment operators. The visual environment evokes absolute precision, calculated calm under pressure, and rapid triage efficiency. 

The aesthetic is rooted in **Technical Minimalism** blended with **Tactical Monospace Realism**:
- High-density telemetry displays with near-zero fluff or decorative overhead.
- Tactile, crisp surface segmentations through razor-sharp 1px structural outlines.
- Strategic luminescent indicators (subtle micro-glows on critical telemetry state changes) that direct visual attention instantly across multi-monitor control centers.
- Utilitarian hierarchy prioritizing machine data readability, deterministic audit logs, and clear adversary vs. defender attribution.

## Colors

The palette operates under a high-contrast dark-mode mandate engineered to mitigate eye fatigue across sustained operational watches while ensuring unambiguous semantic distinction.

### Surfaces & Boundaries
- **Base Canvas (`#0B0F14`)**: Pitch slate baseline for zero-distraction focus.
- **Panel Surface (`#131A22`)**: Low-reflectance containment panels providing depth separation without high lightness deltas.
- **Structural Outlines (`#1E293B` to `#223040`)**: Exact 1px dividers establishing firm spatial containment.

### Tactical Attribution & Status
- **Defensive Line (Blue - `#3B82F6`)**: Blue team operations, telemetry baseline confirmations, active isolation perimeters.
- **Adversarial Vector (Red - `#FF4D4F`)**: Ingress violations, red team actions, sandbox breakout indicators.
- **Tenant LLM (Purple - `#A78BFA`)**: Isolated cognitive workload instances, model-driven prompt analysis, autonomous tokens.
- **State Semantics**: Verified clearance runs on `#22C55E`; latency/escalation warnings anchor on `#F59E0B`; central routing uses clean zinc `#F8FAFC`.
- **Text Layers**: Primary data points rely on `#F1F5F9` (95% luminance) against secondary metrics in `#94A3B8` (65% luminance).

## Typography

Typography enforces a strict cognitive split between narrative context and computational data:

- **Executive UI (`Inter`)**: Controls headers, contextual directives, modal descriptions, and high-level summaries. Tight negative tracking lends authority and structural density to compact layouts.
- **Telemetry & Identity (`JetBrains Mono`)**: Strict tabular alignment for hashes, IP addresses, memory addresses, port bindings, latency counters, and threat vectors.
- **Label-Caps Standard**: All metadata labels, column headers, and status markers are presented in JetBrains Mono uppercase with expanded letter-spacing (`0.08em`) to guarantee immediate visual anchor points during fast scanning.

## Layout & Spacing

The layout operates on a compact 4px base rhythm designed for extreme spatial economy. Screen real estate is treated as an operational asset:

- **Grid Architecture**: A 24-column fluid layout for desktop operations (allowing split multi-pane triage streams, containment matrices, and real-time logs) transitioning to a single-column stacked triage model on mobile monitors.
- **Panel Boundaries**: Gaps between structural inspection frames use precise 12px (`0.75rem`) gutters, keeping operational data coherent and unified within the analyst's visual center.
- **Density Scaling**: Component paddings favor `space-xs` (4px) to `space-md` (12px), restricting empty negative space to what is strictly required to prevent input collisions and optical bleeding.

## Elevation & Depth

Depth is established primarily through **Surface Tiers** and **Low-Contrast Outlines** rather than soft ambient dropshadows:

- **Layer 0 (Base)**: `#0B0F14` foundational canvas.
- **Layer 1 (Panels)**: `#131A22` bounded with a continuous 1px `#223040` stroke. No box-shadow.
- **Layer 2 (Overlays, Flyouts & Modals)**: `#18222D` with an intensified border (`#33475E`) and a controlled deep drop shadow: `0 8px 24px -4px rgba(0, 0, 0, 0.75)`.
- **Telemetry Micro-Glow**: Verified state tags, active breaches, and adversarial locks use tight, concentrated luminescent glows (`box-shadow: 0 0 8px -1px var(--token-color)` at 30-40% opacity) to simulate active hardware status diodes.

## Shapes

The design system employs **Soft (`1`)** corner geometry with disciplined restraint:
- Core panels, status indicators, badges, and input elements leverage small corner radii (4px / `0.25rem`) to maintain an engineered, hardware-console impression.
- Larger containers and isolation drawers scale to a maximum of 8px (`0.5rem`).
- Full pill rounding is restricted solely to live status pulses and LED diode emitters. High curvature is strictly avoided to preserve horizontal scanning speed across data tables.

## Components

### Buttons
- **Primary / Containment Execute**: Background `#3B82F6`, text `#F8FAFC`, 4px radius, 1px border `rgba(255,255,255,0.15)`. Active states compress subtly with an internal highlight.
- **Destructive / Red Team Intercept**: Background `#FF4D4F`, text `#0B0F14`, font weight 600.
- **Ghost / Utility**: Background transparent, border 1px solid `#223040`, text `#94A3B8`. Hover converts border to `#3B82F6` and text to `#F1F5F9`.

### Status Indicators & Pills
- Rendered in `JetBrains Mono` (`label-caps`), padding `2px 6px`, 4px radius.
- **Attacker / Breach**: Background `rgba(255, 77, 79, 0.12)`, text `#FF4D4F`, border `1px solid rgba(255, 77, 79, 0.35)`. Subtle `0 0 6px rgba(255, 77, 79, 0.25)` outer glow.
- **Verified Ledger**: Background `rgba(34, 197, 94, 0.12)`, text `#22C55E`, border `1px solid rgba(34, 197, 94, 0.35)`.
- **Tenant LLM Activity**: Background `rgba(167, 139, 250, 0.12)`, text `#A78BFA`, border `1px solid rgba(167, 139, 250, 0.35)`.

### Input & Filter Fields
- Background `#0B0F14`, border `1px solid #1E293B`, 4px radius.
- Placeholder text in `#475569`, active text in `JetBrains Mono` `#F1F5F9`.
- Focus state activates a sharp 1px border highlight in `#3B82F6` with zero outer ring spread.

### Telemetry Cards & Panels
- Background `#131A22`, 1px border `#223040`. Header rows feature an integrated hairline bottom border `#1E293B` and uppercase label tracking.

### Specialized Component: Isolation Stream Row
- Alternating subtle row fills (`#131A22` to `#10161D`).
- Monospace hash preview, latency metric, ingress/egress vector, and team origin pill aligned along a rigid horizontal datum line.