---
name: Crisp Enterprise Security Console
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#006329'
  on-tertiary: '#ffffff'
  tertiary-container: '#007f36'
  on-tertiary-container: '#c7ffca'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#7ffc97'
  tertiary-fixed-dim: '#62df7d'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005320'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  code-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies high-assurance cybersecurity, forensic precision, and enterprise infrastructure control. Designed specifically for security operations centers (SOC), hardware isolation managers, and red/blue adversarial telemetry teams, the aesthetic rejects ornamental distraction in favor of immaculate clarity, clinical sharpness, and rapid data legibility.

The style is defined as **Technical Precision Minimalist**: pure surgical surfaces, structural micro-borders, and high-contrast typographic hierarchy. It evokes absolute reliability, operational command, and calm authority under incident response pressure.

## Colors

The light-mode architecture uses calibrated slate steps for distinct surface layers, eliminating visual fatigue while preserving extreme contrast:

- **Base Canvas & Surfaces**: Base viewport background sits at `#F8FAFC` (Slate 50). Primary elevated cards, data grids, and inspection panels use `#FFFFFF`. Inset monitoring wells, table headers, and structural rails use `#F1F5F9` (Slate 100).
- **Hairline Dividers**: `#E2E8F0` (Slate 200) defines clean borders and compartmentalized isolation boundaries without heavy weight.
- **Typography & Structural Contrast**: `#0F172A` (Slate 900) for primary headers, critical readouts, and state metrics; `#334155` (Slate 700) for secondary metadata, labels, and table cells; `#64748B` (Slate 500) for timestamps and low-priority telemetry.

### Functional Roles
- **Red (`#EF4444`)**: Adversary activity, Red Team telemetry, critical intrusion alerts, hardware tamper flags, and terminated execution contexts.
- **Blue (`#2563EB`)**: Blue Team defensive rules, active isolation enclaves, endpoint enforcement policies, and primary control triggers.
- **Purple (`#7C3AED`)**: Client LLM operations, neural pipeline sandboxing, prompt-injection monitors, and synthetic inference logs.
- **Green (`#16A34A`)**: Cryptographic signature verified, hardware-enforced root of trust, healthy heartbeat, safe perimeter.
- **Amber (`#D97706`)**: Anomaly warnings, policy divergence, degraded attestations, and rate limit thresholds.

## Typography

The typographic system utilizes **Inter** for all interface controls, headings, and metric labels to maintain scanning efficiency and zero visual ambiguity. 

**JetBrains Mono** is mandatory for all machine-generated content: SHA-256 signatures, memory register addresses, isolated process IDs, prompt hashes, timestamp counters, and telemetry payloads. Hexadecimal codes and hardware registers must always render with standard tabular figures to preserve column alignment across live-updating log streams.

## Layout & Spacing

The layout is built upon a dense, high-utility 12-column grid designed for dense information displays:
- **Canvas Behavior**: Fluid across full viewports with an optional maximum content boundary of 1920px for ultrawide monitoring dashboards.
- **Rhythm**: Compact 4px base increment. Data tables and forensic grids leverage `space-xs` (4px) and `space-sm` (8px) padding to maximize situational visibility per square inch.
- **Breakpoints**:
  - `Desktop (>1280px)`: Fixed-width collapsible multi-rail sidebar navigation (240px default / 64px compact), multi-pane split triage views (3-column layout: attack graph, incident details, raw audit logs).
  - `Tablet (768px - 1279px)`: 2-column stacked layout with secondary inspector panels sliding in as contextual drawers.
  - `Mobile (<768px)`: Single-column linear layout; live data tables convert to scrollable micro-cards with pinned status badges.

## Elevation & Depth

This system avoids heavy drop shadows and blur filters, maintaining an enterprise instrumentation feel. Depth is articulated via **Tonal Surfaces** and **Crisp Hairlines**:

- **Ground Level (Canvas)**: `#F8FAFC` — the root substrate.
- **Level 1 (Card & Module)**: `#FFFFFF` encased in a solid `1px solid #E2E8F0` border. Zero shadow in neutral state; a hairline accent glow or subtle `0 1px 2px rgba(15, 23, 42, 0.04)` for ground separation.
- **Level 2 (Dropdowns, Overlays & Popovers)**: `#FFFFFF` surface with `1px solid #CBD5E1` border and a clinical shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modal Isolation Shields & Critical Overrides)**: `#FFFFFF` framed with `1px solid #94A3B8`, backed by a 40% `#0F172A` scrim with `backdrop-filter: blur(2px)`.
- **Active State / Selected Focus**: Indicated by a high-contrast `1px solid` border in the context's functional color (`#2563EB`, `#EF4444`, or `#7C3AED`) accompanied by an outer `0 0 0 1px` ring.

## Shapes

The design system enforces a disciplined, compact corner radius (`roundedness: 1`). Controls, badges, code snippets, and modal panels feature subtle 4px (`0.25rem`) rounded corners, conveying a tight, machine-tooled software instrument. 

Fully circular pills are avoided entirely—even status tags use square-proportioned micro-radii to maintain horizontal grid alignment and data sheet structure.

## Components

### Buttons
- **Primary Blue Team / Default Action**: Background `#2563EB`, foreground `#FFFFFF`, border `1px solid #1D4ED8`. Hover: `#1D4ED8`.
- **Destructive / Red Team Override**: Background `#EF4444`, foreground `#FFFFFF`, border `1px solid #DC2626`. Hover: `#DC2626`.
- **Secondary / Neutral Control**: Background `#FFFFFF`, foreground `#0F172A`, border `1px solid #E2E8F0`. Hover: `#F1F5F9`.
- **Ghost / Tool Bar**: Background transparent, foreground `#334155`. Hover: `#F1F5F9`, border `1px solid transparent`.
- Height: 32px for compact table tools, 36px for standard forms. Font: Inter, 13px, weight 500.

### Status Chips & Functional Badges
- Displayed using semi-opaque tinted backgrounds with solid high-contrast borders and matching text:
  - **Red / Blocked**: Background `rgba(239, 68, 68, 0.08)`, border `rgba(239, 68, 68, 0.25)`, text `#DC2626`.
  - **Blue / Enforced**: Background `rgba(37, 99, 235, 0.08)`, border `rgba(37, 99, 235, 0.25)`, text `#1D4ED8`.
  - **Purple / LLM Context**: Background `rgba(124, 58, 237, 0.08)`, border `rgba(124, 58, 237, 0.25)`, text `#6D28D9`.
  - **Green / Isolated & Safe**: Background `rgba(22, 163, 74, 0.08)`, border `rgba(22, 163, 74, 0.25)`, text `#15803D`.
  - **Amber / Anomaly**: Background `rgba(217, 119, 6, 0.08)`, border `rgba(217, 119, 6, 0.25)`, text `#B45309`.
- Badges feature a leading 6px circular indicator dot reflecting the functional status color.

### Form Inputs & Telemetry Filters
- Surface: `#FFFFFF`, border `1px solid #CBD5E1`, text `#0F172A`.
- Placeholder text: `#94A3B8`.
- Focus state: border `#2563EB`, box-shadow `0 0 0 1px #2563EB`.
- Embedded search/filter boxes within audit streams default to JetBrains Mono at 12px for regex and query input.

### Checkboxes & Radios
- Size: 16px × 16px. Border `1px solid #CBD5E1`, background `#FFFFFF`, corner radius 2px.
- Checked: Background matches action domain (default Blue `#2563EB`, or Red `#EF4444` in revocation matrices), checkmark icon pure white.

### Data Tables & Event Grids
- **Header**: Background `#F1F5F9`, border-bottom `1px solid #CBD5E1`. Text uppercase Inter, 11px, weight 600, color `#475569`.
- **Row**: Background `#FFFFFF`, alternating zebra (optional): `#F8FAFC`. Bottom divider `1px solid #E2E8F0`. Hover row: `#F1F5F9`.
- **Cells**: Font Inter or JetBrains Mono depending on data type, height 36px, vertical centering.

### Cryptographic & Hash Blocks
- Raw payload displays, key fingerprints, and process memory maps: surface `#F1F5F9`, border `1px solid #E2E8F0`, padding 8px 12px, font JetBrains Mono 11px, color `#0F172A`. Includes an integrated copy icon button with instant green verification check.